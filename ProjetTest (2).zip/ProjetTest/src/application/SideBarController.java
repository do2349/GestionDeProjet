package application;

import java.io.IOException;
import java.net.URL;
import java.util.ResourceBundle;

import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.input.MouseEvent;
import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.BorderPane;

public class SideBarController implements Initializable {
	
	
	@FXML 
	private BorderPane bp;
	@FXML
	private AnchorPane ap; 
	
	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		// TODO Auto-generated method stub
		
	}
	
	@FXML 
	private void home(MouseEvent e) {
		bp.setCenter(ap);
	}
	
	@FXML 
	private void StudentList(MouseEvent e) {
		loadPage("StudentList");
	}

	@FXML 
	private void SubjectsList(MouseEvent e) {
		loadPage("SubjectsList");
	}
	
	private void loadPage(String page) {
		Parent root = null;
		try {
			root = FXMLLoader.load(getClass().getResource("/" + page + ".fxml"));
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		bp.setCenter(root);
	}
	
}
