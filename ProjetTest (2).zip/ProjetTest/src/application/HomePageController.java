package application;


import java.net.URL;
import java.util.ResourceBundle;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.ChoiceBox;
import javafx.scene.control.Label;

public class HomePageController implements Initializable {
	
	@FXML
	private Label myLabel;
	
	@FXML
	private ChoiceBox<String> formationChoiceBox;
	
	private String[] formations = {"Formation 1", "Formation 2", "Formation 3"};

	@Override
	public void initialize(URL arg0, ResourceBundle arg1) {
		formationChoiceBox.getItems().addAll(formations);
		formationChoiceBox.setOnAction(this::getFormation);
	}
	
	public void getFormation(ActionEvent e) {
		String myFormation = formationChoiceBox.getValue();
		myLabel.setText(myFormation);
	}
	
}